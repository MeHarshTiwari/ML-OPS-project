import json
import streamlit as st
from project_core import METRICS_FILE, predict_grade

st.set_page_config(page_title="Student Grade Predictor", page_icon="🎓", layout="centered")
st.title("🎓 Student Final Grade Predictor")
st.caption("Random Forest regression trained on the UCI Student Performance dataset")

with st.form("prediction_form"):
    col1, col2 = st.columns(2)
    with col1:
        age = st.slider("Age", 15, 22, 18)
        sex = st.selectbox("Sex", ["F", "M"])
        address = st.selectbox("Home area", ["U", "R"], format_func=lambda x: "Urban" if x == "U" else "Rural")
        studytime = st.select_slider("Weekly study time", options=[1, 2, 3, 4], value=2,
            format_func=lambda x: {1:"< 2 hours",2:"2–5 hours",3:"5–10 hours",4:"> 10 hours"}[x])
        failures = st.slider("Past class failures", 0, 4, 0)
        schoolsup = st.selectbox("Extra school support", ["no", "yes"])
        famsup = st.selectbox("Family educational support", ["yes", "no"])
        higher = st.selectbox("Wants higher education", ["yes", "no"])
    with col2:
        internet = st.selectbox("Internet at home", ["yes", "no"])
        famrel = st.slider("Family relationship quality", 1, 5, 4)
        freetime = st.slider("Free time", 1, 5, 3)
        goout = st.slider("Going out with friends", 1, 5, 3)
        health = st.slider("Health status", 1, 5, 4)
        absences = st.number_input("School absences", min_value=0, max_value=93, value=4)
        g1 = st.slider("First-period grade (G1)", 0, 20, 12)
        g2 = st.slider("Second-period grade (G2)", 0, 20, 12)

    submitted = st.form_submit_button("Predict final grade", use_container_width=True)

if submitted:
    values = {
        "age": age, "sex": sex, "address": address, "studytime": studytime,
        "failures": failures, "schoolsup": schoolsup, "famsup": famsup,
        "higher": higher, "internet": internet, "famrel": famrel,
        "freetime": freetime, "goout": goout, "health": health,
        "absences": absences, "G1": g1, "G2": g2,
    }
    try:
        grade = predict_grade(values)
        st.metric("Predicted final grade", f"{grade:.1f} / 20")
        st.progress(min(grade / 20, 1.0))
        if grade >= 16:
            st.success("Excellent predicted performance")
        elif grade >= 10:
            st.info("Likely to pass")
        else:
            st.warning("Student may need additional academic support")
    except Exception as exc:
        st.error(str(exc))

if METRICS_FILE.exists():
    with st.expander("Model evaluation"):
        metrics = json.loads(METRICS_FILE.read_text(encoding="utf-8"))
        st.json(metrics)

st.divider()
st.caption("Educational demonstration only. Predictions should not be used as the sole basis for real academic decisions.")
