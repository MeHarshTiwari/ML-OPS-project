# Student Performance Prediction — Python ML Project

A complete machine-learning mini project that predicts a student's final grade (`G3`, from 0 to 20).

## Dataset

**Student Performance**, UCI Machine Learning Repository, dataset ID 320. The script downloads the official ZIP automatically on first run.

Dataset page: https://archive.ics.uci.edu/dataset/320/student+performance

The project uses the Mathematics course file and selected demographic, study, attendance, and previous-grade features.

## ML workflow

1. Download the official dataset
2. Read the semicolon-separated CSV
3. Select useful features
4. One-hot encode categorical values
5. Split data into 80% training and 20% testing
6. Train a Random Forest Regressor
7. Calculate MAE, RMSE, and R²
8. Save the model using Joblib
9. Use a Streamlit web app for predictions

## Project files

- `project_core.py` — download, preprocessing, training, saving, and prediction logic
- `train.py` — trains and evaluates the model
- `app.py` — interactive Streamlit web interface
- `requirements.txt` — Python packages
- `run_windows.bat` — easy Windows launcher

## Run on Windows

Open Command Prompt inside this folder and run:

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python train.py
streamlit run app.py
```

Or double-click `run_windows.bat` after Python is installed.

## Notes

- Internet is required only the first time, to download the UCI dataset.
- The trained model and evaluation results are saved inside `models/`.
- This is an educational project, not a real academic decision system.
