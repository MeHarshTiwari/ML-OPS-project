from project_core import MODEL_FILE, train_and_save

if __name__ == "__main__":
    try:
        metrics = train_and_save()
        print("\nModel trained successfully.")
        print(f"Saved model: {MODEL_FILE}")
        print(f"Rows: {metrics['dataset_rows']}")
        print(f"MAE: {metrics['mae']}")
        print(f"RMSE: {metrics['rmse']}")
        print(f"R2 score: {metrics['r2']}")
    except Exception as exc:
        print(f"Training failed: {exc}")
        raise
