@echo off
setlocal
cd /d "%~dp0"
echo Installing required Python packages...
python -m pip install -r requirements.txt
if errorlevel 1 goto error

echo.
echo Training the model and downloading the UCI dataset if needed...
python train.py
if errorlevel 1 goto error

echo.
echo Opening the Streamlit application...
python -m streamlit run app.py
goto end

:error
echo.
echo Something failed. Read the error shown above.
pause

:end
endlocal
