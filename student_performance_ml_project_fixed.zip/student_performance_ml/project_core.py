from pathlib import Path
import io
import json
import shutil
import urllib.request
import zipfile

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
DATA_FILE = DATA_DIR / "student-mat.csv"
MODEL_FILE = MODEL_DIR / "student_grade_model.joblib"
METRICS_FILE = MODEL_DIR / "metrics.json"

FEATURES = [
    "age", "sex", "address", "studytime", "failures", "schoolsup",
    "famsup", "higher", "internet", "famrel", "freetime", "goout",
    "health", "absences", "G1", "G2"
]
TARGET = "G3"
CATEGORICAL = ["sex", "address", "schoolsup", "famsup", "higher", "internet"]
NUMERIC = [column for column in FEATURES if column not in CATEGORICAL]

# Current and legacy official UCI download locations.
UCI_ZIP_URLS = [
    "https://archive.ics.uci.edu/static/public/320/student+performance.zip",
    "https://archive.ics.uci.edu/ml/machine-learning-databases/00320/student.zip",
]


def _find_csv(folder: Path) -> Path | None:
    """Find student-mat.csv without assuming its folder or letter case."""
    for path in folder.rglob("*"):
        if path.is_file() and path.name.lower() == "student-mat.csv":
            return path
    return None


def _extract_nested_archives(content: bytes, destination: Path) -> None:
    """Extract a ZIP and any ZIP files contained inside it."""
    pending: list[tuple[bytes, Path]] = [(content, destination)]
    processed = 0

    while pending:
        archive_bytes, output_folder = pending.pop()
        processed += 1
        if processed > 20:
            raise RuntimeError("Too many nested archives were found in the dataset download.")

        output_folder.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
            archive.extractall(output_folder)

        for nested_zip in output_folder.rglob("*.zip"):
            nested_output = nested_zip.with_suffix("")
            try:
                pending.append((nested_zip.read_bytes(), nested_output))
                nested_zip.unlink()
            except OSError:
                continue


def _download_using_zip_urls() -> Path | None:
    errors: list[str] = []

    for index, url in enumerate(UCI_ZIP_URLS, start=1):
        temporary_folder = DATA_DIR / f"uci_download_{index}"
        shutil.rmtree(temporary_folder, ignore_errors=True)

        try:
            request = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0 StudentGradeMLProject/1.1"},
            )
            with urllib.request.urlopen(request, timeout=45) as response:
                content = response.read()

            _extract_nested_archives(content, temporary_folder)
            candidate = _find_csv(temporary_folder)
            if candidate is not None:
                shutil.copy2(candidate, DATA_FILE)
                shutil.rmtree(temporary_folder, ignore_errors=True)
                return DATA_FILE

            errors.append(f"No student-mat.csv in archive from {url}")
        except Exception as exc:
            errors.append(f"{url}: {exc}")
        finally:
            shutil.rmtree(temporary_folder, ignore_errors=True)

    return None


def _download_using_ucimlrepo() -> Path | None:
    """Fallback to UCI's Python client if archive URLs are unavailable."""
    try:
        from ucimlrepo import fetch_ucirepo

        dataset = fetch_ucirepo(id=320)
        features = dataset.data.features.copy()
        targets = dataset.data.targets.copy()

        # Depending on the client version, targets may contain one or more columns.
        if TARGET not in features.columns:
            if TARGET in targets.columns:
                features[TARGET] = targets[TARGET].to_numpy()
            elif len(targets.columns) == 1:
                features[TARGET] = targets.iloc[:, 0].to_numpy()

        required = set(FEATURES + [TARGET])
        if not required.issubset(features.columns):
            return None

        features.to_csv(DATA_FILE, sep=";", index=False)
        return DATA_FILE
    except Exception:
        return None


def download_uci_dataset() -> Path:
    """Download the official UCI Student Performance mathematics dataset."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    if DATA_FILE.exists() and DATA_FILE.stat().st_size > 1000:
        return DATA_FILE

    # Clean up a bad or empty file left from an interrupted run.
    DATA_FILE.unlink(missing_ok=True)

    downloaded = _download_using_zip_urls()
    if downloaded is None:
        downloaded = _download_using_ucimlrepo()

    if downloaded is None or not downloaded.exists():
        raise RuntimeError(
            "The UCI dataset could not be downloaded. Check the internet connection, "
            "then run again. You can also manually place student-mat.csv inside the data folder."
        )

    return downloaded


def load_data() -> pd.DataFrame:
    path = download_uci_dataset()
    dataframe = pd.read_csv(path, sep=";")
    required = set(FEATURES + [TARGET])
    missing = required.difference(dataframe.columns)
    if missing:
        raise ValueError(f"Dataset is missing columns: {sorted(missing)}")
    return dataframe


def make_pipeline() -> Pipeline:
    preprocessor = ColumnTransformer(
        transformers=[
            ("categorical", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
            ("numeric", "passthrough", NUMERIC),
        ]
    )
    model = RandomForestRegressor(
        n_estimators=350,
        max_depth=10,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1,
    )
    return Pipeline([("preprocessor", preprocessor), ("model", model)])


def train_and_save() -> dict:
    dataframe = load_data()
    features = dataframe[FEATURES]
    target = dataframe[TARGET]
    x_train, x_test, y_train, y_test = train_test_split(
        features, target, test_size=0.2, random_state=42
    )

    pipeline = make_pipeline()
    pipeline.fit(x_train, y_train)
    predictions = pipeline.predict(x_test)

    metrics = {
        "dataset_rows": int(len(dataframe)),
        "training_rows": int(len(x_train)),
        "testing_rows": int(len(x_test)),
        "mae": round(float(mean_absolute_error(y_test, predictions)), 3),
        "rmse": round(float(mean_squared_error(y_test, predictions) ** 0.5), 3),
        "r2": round(float(r2_score(y_test, predictions)), 3),
    }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, MODEL_FILE)
    METRICS_FILE.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics


def load_model():
    if not MODEL_FILE.exists():
        train_and_save()
    return joblib.load(MODEL_FILE)


def predict_grade(values: dict) -> float:
    model = load_model()
    row = pd.DataFrame([values], columns=FEATURES)
    prediction = float(model.predict(row)[0])
    return float(np.clip(prediction, 0, 20))
